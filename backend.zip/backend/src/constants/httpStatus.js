export const BAD_REQUEST = 400;
